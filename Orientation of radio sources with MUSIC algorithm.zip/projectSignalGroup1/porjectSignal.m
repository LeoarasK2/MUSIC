load('401101705.mat');


num_elements = 40; 
num_samples = 1000; 
d = 0.5; % Distance between elements (in terms of wavelength)
fc = 20e6; 
c = 3e8; % سرعت نور
lambda = c / fc; 

% Extract the received data
X = recieve;

% covariance matrix
R = (X * X') / num_samples;


angles = -90:0.1:90;
Pmusic = zeros(size(angles));

%مقادیر ویژه
[E, D] = eig(R);
eigenvalues = diag(D);
[~, idx] = sort(eigenvalues, 'ascend');
En = E(:, idx(1:num_elements-2)); % Noise

% MUSIC 
for i = 1:length(angles)
    a = exp(-1j * 2 * pi * d * sind(angles(i)) * (0:num_elements-1).');
    Pmusic(i) = 1 / (a' * (En * En') * a);
end

% Find peaks 
[~, locs] = findpeaks(abs(Pmusic), 'SortStr', 'descend', 'NPeaks', 2);

estimated_angles = angles(locs);

figure;
plot(angles, abs(Pmusic));
xlabel('Angle (degrees)');
ylabel('Spatial Spectrum ');
title('MUSIC Spectrum');
grid on;

disp('Estimated Angles of Arrival (AoA):');
disp(estimated_angles);
